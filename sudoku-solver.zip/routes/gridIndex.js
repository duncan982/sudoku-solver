const gridIndex = {
    '1': 'A1B1C1',
    '2': 'A2B2C2',
    '3': 'A3B3C3',
    '4': 'D1E1F1',
    '5': 'D2E2F2',
    '6': 'D3E3F3',
    '7': 'G1H1I1',
    '8': 'G2H2I2',
    '9': 'G3H3I3'
  };

module.exports = gridIndex 
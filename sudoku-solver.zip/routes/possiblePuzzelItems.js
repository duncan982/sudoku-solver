// create a list of valid items
const possiblePuzzelItems = [1, 2, 3, 4, 5, 6, 7, 8, 9];

module.exports = possiblePuzzelItems;

const gridIndexValues = {
     'A1B1C1': 1,
     'A2B2C2': 2,
     'A3B3C3': 3,
     'D1E1F1': 4,
     'D2E2F2': 5,
     'D3E3F3': 6,
     'G1H1I1': 7,
     'G2H2I2': 8,
     'G3H3I3': 9
  };

module.exports = gridIndexValues
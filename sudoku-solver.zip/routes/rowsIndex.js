const rowsIndex = {
  A: 0,
  B: 9,
  C: 18,
  D: 27,
  E: 36,
  F: 45,
  G: 54,
  H: 63,
  I: 72
};

module.exports = rowsIndex;

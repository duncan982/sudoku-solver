  // recreate grid quarter keys
  const gridKeys = [
    "A1B1C1",
    "A2B2C2",
    "A3B3C3",
    "D1E1F1",
    "D2E2F2",
    "D3E3F3",
    "G1H1I1",
    "G2H2I2",
    "G3H3I3"
  ];

  module.exports = gridKeys;